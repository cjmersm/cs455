

package cs455.cdn.node;



import java.io.*;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.nio.channels.Channel;
import java.nio.channels.DatagramChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;



import cs455.cdn.communications.*;
import cs455.cdn.mst.Edge;
import cs455.cdn.mst.KruskalEdges;
import cs455.cdn.threads.ReadOrWrite;
import cs455.cdn.threads.ThreadPool;
import cs455.cdn.util.ConsoleListener;

@SuppressWarnings("unused")
public class MessagingNode extends Node {


	private String node_id;
	private String registry_host;
	private int registry_port;
	private int thread_pool_size;

	private int tcp_port;
	private int udp_port;
	private String my_address;

	private SocketChannel regsc;
	private TCPConnection tcpc;

	private ServerSocketChannel tcpserver;
	private DatagramChannel udpserver;
	private ServerSocketChannel scalableServer;


	private String cdnConnectionType = "tcp";
	private KruskalEdges vv; 
	private KruskalEdges cdnPathList;
	private ConnectionFactory cf;

	private String tempfilename = "";
	private ThreadPool tPool;


	@SuppressWarnings("static-access")
	MessagingNode(String node_id, String registry_host, int registry_port, int thread_pool_size){
		
		this.type = 'n';

		this.node_id = node_id;
		this.registry_host = registry_host;
		this.registry_port = registry_port;
		this.thread_pool_size = thread_pool_size;

		nodelist = new ArrayList<String>();
		cf = new ConnectionFactory("tcp"); // Defaults


		try{

			// Create and bind a tcp channel to listen for connections on.
			tcpserver = ServerSocketChannel.open();
			tcpserver.socket().bind(new InetSocketAddress(0));
			tcp_port = tcpserver.socket().getLocalPort();

			// Also create and bind a DatagramChannel to listen on.
			udpserver = DatagramChannel.open();
			udpserver.socket().bind(new InetSocketAddress(0));
			udp_port = udpserver.socket().getLocalPort();

			// Address of the machine
			my_address = tcpserver.socket().getInetAddress().getLocalHost().getHostAddress();

			// Specify non-blocking mode for both channels, since our
			// Selector object will be doing the blocking for us.
			tcpserver.configureBlocking(false);
			udpserver.configureBlocking(false);



			File file = new File(node_id+".file");
			if(file.exists()){
				file.delete();
			}


		} catch (IOException e){
			e.printStackTrace();
		}
	}

	public void regConnect(){
		try{
			regsc = SocketChannel.open();
			regsc.configureBlocking(false);

			regsc.connect(new InetSocketAddress(registry_host, registry_port));	
			tcpc = new TCPConnection(regsc);

			tcpc.write(REGISTRY_REQUEST+";"+node_id+";"+my_address+";"+tcp_port+";"+udp_port);	
			Thread.sleep(11); // So that it has time to read otherwise there is no message.


			byte[] b = tcpc.read();

			String message = byteArrayToString(b);
			Scanner mesScan = new Scanner(message);
			mesScan.useDelimiter(";");

			mesScan.nextInt();
			mesScan.nextInt();
			String res = mesScan.next();


			System.out.println("Registration: "+res);

			mesScan.close();
			regsc.close();

			Thread t2 = new Thread(listen);
			t2.start();


		} catch (IOException  e){
			System.out.println("No Register Was Found, Going into Part 2 Mode!");
			scalable();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	Runnable listen = new Runnable(){
		public void run(){

			System.out.println("Waiting for Connection...");
			while(true){
				try {

					SocketChannel sc = tcpserver.accept();

					if (sc == null) {
						//System.out.println("is this thing on?");
					} else { // received an incoming connection
						//System.out.println("Received a connection");
						TCPConnection t = new TCPConnection(sc);

						byte[] b = t.read();
						String message = byteArrayToString(b);


						Scanner mesScan = new Scanner(message);
						mesScan.useDelimiter(";");

						int num = mesScan.nextInt();

						////////////////////////////////////////////////////////////////////////


						if(num == PEER_NODE_LIST_MESSAGE) {
							nodelist = new ArrayList<String>();

							cdnConnectionType = mesScan.next();
							cf = new ConnectionFactory(cdnConnectionType);

							//int numConnections = mesScan.nextInt();

							Scanner listScan = new Scanner(message);
							listScan.useDelimiter("\n");

							listScan.next();

							while(listScan.hasNext()){
								nodelist.add(listScan.next());
							}

							listScan.close();
							System.out.println("Received Peer Node List");

							justifyConnections();
						}


						////////////////////////////////////////////////////////////////////////


						else if(num == NODE_TO_NODE_JUSTIFY){
							String node = message.replaceFirst(NODE_TO_NODE_JUSTIFY+";", "");

							//System.out.println("MESSAGE : "+message);
							//System.out.println("NODE ST : "+node);

							nodelist.add(node);
							System.out.println(node+" has been added.");
						}

						////////////////////////////////////////////////////////////////////////

						else if(num == WEIGHT_UPDATE){

							System.out.println("Computing Minimum Spanning Tree");
							computeMinimumSpanningTree(message.replaceFirst(WEIGHT_UPDATE+";\n", ""));		
						}

						////////////////////////////////////////////////////////////////////////

						else if(num == DATA_PACKET){
							int flag = mesScan.nextInt();


							if(flag == 1){
								tempfilename = mesScan.next();
								if(!tempfilename.contains("/")){
									tempfilename = "/tmp/mersman/"+tempfilename;
								}

								File f = new File(tempfilename);
								f.delete();

								cdnPathList = new KruskalEdges();
								while (mesScan.hasNextLine()){
									String line = mesScan.nextLine();
									if(!line.equals(";")){
										Edge e = new Edge(getNodeA(line),getNodeB(line),getWeight(line));
										cdnPathList.insertEdge(e);
									}
								}
								System.out.println("Receiving Data: "+tempfilename);
							}
							else if(flag == 2){
								File f = new File(tempfilename);
								if(!tempfilename.contains("/")){
									tempfilename = "/tmp/mersman/"+tempfilename;
								}

								File dir=new File("/tmp/mersman");
								dir.mkdirs();

								FileOutputStream fos = new FileOutputStream(f,true);
								byte[] arr = Arrays.copyOfRange(b, (num+";2;").length(), b.length);

								fos.write(arr);
								System.out.print(".");
								fos.close();
							}
							else { // flag == 3
								System.out.println("Done");
								sendData(tempfilename);
							}

						}

						////////////////////////////////////////////////////////////////////////

						mesScan.close();
					}

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	};

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void initializeSending(){
		cdnPathList=vv;
	}

	public void sendData(String filename){
		ArrayList<byte[]> sections = new ArrayList<byte[]>();
		FileInputStream fileInputStream=null;

		File file = new File(filename);

		byte[] bFile = new byte[(int) file.length()];

		try {
			//convert file into array of bytes
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bFile);
			fileInputStream.close();

			//cdnPathList = new KruskalEdges();


			String firstMessage = DATA_PACKET+";1;"+filename+";";


			for(Edge e : cdnPathList.getEdges()){

				String a = e.getVertexA();
				String b = e.getVertexB();

				if(getNodeName(a).equals(node_id) || getNodeName(b).equals(node_id)){

				}
				else{
					firstMessage += "\n"+a+"\t"+b+"\t"+e.getWeight();
					//cdnPathList.insertEdge(e);
					//System.out.println(e);
				}
			}
			sections.add(firstMessage.getBytes());

			if(bFile.length>4096){
				byte[] section = new byte[4096];

				int i;
				for( i = 0;i+4096<bFile.length;i+=(4096)){

					section = Arrays.copyOfRange(bFile, i, i+4096);

					sections.add(section);
				}

				byte[] newer = Arrays.copyOfRange(bFile, i, bFile.length);
				sections.add(newer);

			}
			else{
				byte[] section = bFile;
				sections.add(section);
			}

			for(Edge e : cdnPathList.getEdges()){

				String a = e.getVertexA();
				String b = e.getVertexB();

				for(int i = 0;i<=sections.size();i++){
					if(getNodeName(a).equals(node_id)){


						String add = getAddressFromNode(b);
						int port = getPortFromNode(b);

						Connection c = cf.getConnector(cf.getConnection(add, port));

						if(i==sections.size()){
							byte[] total = (DATA_PACKET+";3;").getBytes();
							c.write(total);
							System.out.println("Done!");
						}
						else if(i==0){
							System.out.println("Sending data to "+b);
							c.write(sections.get(i));
						}
						else{
							byte[] total = arrConcat(stringToByteArray(DATA_PACKET+";2;"),sections.get(i));
							c.write(total);
							System.out.print(".");
						}
					}

					if(getNodeName(b).equals(node_id)){
						String add = getAddressFromNode(a);
						int port = getPortFromNode(a);

						Connection c = cf.getConnector(cf.getConnection(add, port));

						if(i==sections.size()){
							byte[] total = (DATA_PACKET+";3;").getBytes();
							c.write(total);
							System.out.println("Done!");
						}
						else if(i==0){
							System.out.println("Sending data to "+a);
							c.write(sections.get(i));
						}
						else{
							byte[] total = arrConcat(stringToByteArray(DATA_PACKET+";2;"),sections.get(i));
							c.write(total);
							System.out.print(".");
						}
					}
				}
			}
		}
		catch(IOException e){
			e.printStackTrace();
			System.out.println("File: "+filename+" does not exist.");
		}

	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	public void computeMinimumSpanningTree(String message){
		Scanner listScan = new Scanner(message);
		listScan.useDelimiter("\n");

		ArrayList<String> edges = new ArrayList<String>();

		while(listScan.hasNext()){
			String line = listScan.next();
			edges.add(line);
		}

		/////////////////////////////////////////////////////////////////////////////////////
		vv = new KruskalEdges();
		while(!edges.isEmpty()){

			String line = removeMinEdge(edges);
			Edge edge = new Edge(getNodeA(line),getNodeB(line),getWeight(line));
			vv.insertEdge(edge);

		}

		for (Edge edge : vv.getEdges()) {
			System.out.println(edge);
		}


		listScan.close();
	}

	//// Helpers for MST ////

	public void printMST(){ // TODO
		if(vv == null){
			System.out.println("There is no MST");
		}
		else{
			String mst = "";
			for(Edge e : vv.getEdges()){
				String nodeA = getNodeName(e.getVertexA());
				String nodeB = getNodeName(e.getVertexB());
				int weight = e.getWeight();

				if(nodeA.equals(node_id)){
					mst+=nodeA+"--"+weight+"--"+nodeB;
				}
				if(nodeB.equals(node_id)){
					mst+=nodeB+"--"+weight+"--"+nodeA;
				}
				//		int locA = mst.indexOf(nodeA);
				//	int locB = mst.indexOf(nodeB);


				//if(locA+)

				//		String s = "hellomynamechris";
				//		String t = "chris";
				//		int locSize = s.length();
				//		int locTest = s.indexOf(t);

				//		System.out.println(locSize + " " + locTest+t.length());
			}


			System.out.println(mst);
		}
	}


	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	public void shutdown() {
		try{
			regsc = SocketChannel.open();
			regsc.configureBlocking(false);

			regsc.connect(new InetSocketAddress(registry_host, registry_port));	
			tcpc = new TCPConnection(regsc);

			tcpc.write(DEREGISTER_REQUEST+";"+node_id+";"+my_address+";"+tcp_port+";"+udp_port);
			Thread.sleep(10); // So that it has time to read otherwise there is no message.


			byte[] b = tcpc.read();

			String message = byteArrayToString(b);
			Scanner mesScan = new Scanner(message);
			mesScan.useDelimiter(";");

			mesScan.nextInt();
			String res = mesScan.next();

			System.out.println("Deregistration: "+res);

			mesScan.close();
			exitNicely();

		} catch (IOException | InterruptedException e){
			e.printStackTrace();
		}
	}


	public synchronized void justifyConnections(){
		ConnectionFactory cf = new ConnectionFactory(cdnConnectionType);

		for(int i=0;i<nodelist.size();i++){
			String node = nodelist.get(i);
			Scanner scan = new Scanner(node);
			scan.useDelimiter(";");

			scan.next();
			String nodeAddress = scan.next();

			int port = 0;
			if(cdnConnectionType.equals("tcp"))
				port = scan.nextInt();
			else if(cdnConnectionType.equals("udp")){
				scan.next(); port=scan.nextInt();
			}

			Channel ch = cf.getConnection(nodeAddress, port);
			Connection c = cf.getConnector(ch);

			try {
				if(cdnConnectionType.equals("tcp")){
					TCPConnection tcpCon = (TCPConnection)c;
					tcpCon.write(NODE_TO_NODE_JUSTIFY+";"+node_id+";"+my_address+";"+tcp_port+";"+udp_port);
				}
				else if(cdnConnectionType.equals("udp")){
					UDPConnection udpCon = (UDPConnection)c;
					udpCon.write("nothing");
				}


				ch.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			scan.close();
		}

	}

	public void setPort(int port){
		try {
			scalableServer = ServerSocketChannel.open();
			scalableServer.socket().bind(new InetSocketAddress(port));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	

	@SuppressWarnings("static-access")
	public void scalable(){
		try {

			tPool = new ThreadPool(thread_pool_size);
			
			setPort(2004);
			System.out.println("Node port set to 2004 on machine "+scalableServer.socket().getInetAddress().getLocalHost().getHostAddress());

			
			Selector select = Selector.open();

			//set up ServerSocketChannel
			
			scalableServer.configureBlocking(false);
			scalableServer.register(select , SelectionKey.OP_ACCEPT);
			
			Set<SelectionKey> keys = select.selectedKeys( );

			System.out.println("Waiting for Connection...");
			//look for accept notifications
			while(true){
				select.select(); //find something that's ready
				

				for(Iterator<SelectionKey> i = keys.iterator( ); i.hasNext( ); ) {
					
                    // Get a key from the set, and remove it from the set
                    SelectionKey key = (SelectionKey)i.next( );
                    i.remove( );
					//housekeeping...
					if (key.isAcceptable()) {
						//accept the connection
						SocketChannel client = scalableServer.accept();
						client.configureBlocking (false);
						client.register(select,SelectionKey.OP_READ | SelectionKey.OP_WRITE);
						
						ReadOrWrite row = new ReadOrWrite(client);
						
						tPool.runTask(row);
					} /*account for other cases*/ 
				}
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	// Start helpers

	private void printArrayList(ArrayList<String> e){
		System.out.println("ArrayList");
		for(int i =0;i<e.size();i++){
			System.out.println("\t"+e.get(i));
		}
	}
	private String removeMinEdge(ArrayList<String> edges){
		String minEdge = " \t \t11";

		for(int i = 0;i<edges.size();i++){
			int a = getWeight(minEdge);
			int b = getWeight(edges.get(i));


			if(b<a){
				minEdge=edges.get(i);
			}
		}

		edges.remove(minEdge);
		return minEdge;
	}
	private String getNodeName(String node){
		Scanner scan = new Scanner(node);
		scan.useDelimiter(";");
		String a = scan.next();
		scan.close();
		return a;
	}
	private String getNodeA(String edge){
		Scanner scan = new Scanner(edge);
		scan.useDelimiter("\t");
		String a = scan.next();
		scan.close();
		return a;
	}
	private String getNodeB(String edge){
		Scanner scan = new Scanner(edge);
		scan.useDelimiter("\t");
		scan.next();
		String b = scan.next();
		scan.close();
		return b;
	}
	private int getWeight(String edge){
		Scanner scan = new Scanner(edge);
		scan.useDelimiter("\t");
		scan.next();
		scan.next();

		int c = scan.nextInt();

		scan.close();
		return c;
	}
	public String getAddressFromNode(String node){
		Scanner scan = new Scanner(node);
		scan.useDelimiter(";");
		scan.next();
		String address = scan.next();
		scan.close();
		return address;
	}
	public int getPortFromNode(String node){
		Scanner scan = new Scanner(node);
		scan.useDelimiter(";");
		scan.next();
		scan.next();

		int port = 0;

		if(cdnConnectionType.equals("tcp")){
			port = scan.nextInt();
		}
		else if(cdnConnectionType.equals("udp")){
			scan.nextInt();
			port = scan.nextInt();
		}
		scan.close();
		return port;
	}
	public void exitNicely() throws IOException {
		regsc.close();
		tcpserver.close();
		udpserver.close();
		System.exit(0);
	}


	// End helpers

	public static void main(String args[])
	{
		if(args.length==4){
			MessagingNode node = new MessagingNode(args[0],args[1],Integer.parseInt(args[2]),Integer.parseInt(args[3]));
			ConsoleListener terminal = new ConsoleListener(node);

			Thread t1 = new Thread(terminal);
			t1.start();

			node.regConnect();

			//Thread t3 = new Thread(node.listenudp);
			//t3.start();
		}
		else{
			System.out.println("Usage: java MessagingNode assigned_id registry-host registry-port threadpool_size");
		}
	}




}

