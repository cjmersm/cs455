package cs455.cdn.threads;


public class WorkerThread implements Runnable{

	ThreadPool tp;
	
	public WorkerThread(ThreadPool tp){
		this.tp = tp;
	}

	public void run(){
		while (true) {

			// get a task to run
			Runnable task = null;
			try {
				task = tp.getTask();
			} catch (InterruptedException ex) {
			}

			System.out.println("Got Task");
			// if getTask() returned null or was interrupted,
			// close this thread by returning.
			if (task == null) {
				System.out.println("Something went wrong?");
				return;
			}

			// run the task, and eat any exceptions it throws
			try {
				task.run();
			} catch (Throwable t) {
				t.printStackTrace();
			}
		}
	}
}
