package cs455.cdn.communications;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;


public class TCPConnection extends Connection {

	SocketChannel sc;
	ByteBuffer bb;

	public TCPConnection(SocketChannel sc){
		this.sc = sc;
		
		bb = ByteBuffer.allocate(4100);
		try {
			while (!this.sc.finishConnect()) {
				// pretend to do something useful here
				//System.out.println("Doing something useful...");.
				//System.out.print(".");
			}
			//System.out.println(".");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
	}

	
	public byte[] read() throws IOException{
		bb.clear();

		int size = sc.read(bb);
		bb.flip();
		
		byte[] temp = new byte[size];
		bb.get(temp);
		
		
		//System.out.println("Read: "+byteArrayToString(temp));
		
		return temp;
	}

	
	public void write(byte[] b) throws IOException{
		bb.clear();
		bb.put(b);
		bb.flip();
		sc.write(bb);
		bb.clear();
	}
	
	
	public void write(String s) throws IOException{
		byte[] b = s.getBytes();
		//System.out.println("Write: "+s);
		this.write(b);
	}
}
